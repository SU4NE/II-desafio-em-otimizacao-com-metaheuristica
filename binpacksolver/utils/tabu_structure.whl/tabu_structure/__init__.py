from .tabu_structure import *

__doc__ = tabu_structure.__doc__
if hasattr(tabu_structure, "__all__"):
    __all__ = tabu_structure.__all__